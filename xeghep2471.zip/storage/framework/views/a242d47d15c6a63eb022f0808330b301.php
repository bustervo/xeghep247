<?php $__env->startSection('title', 'Tạo danh mục mới'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-8">
    <h1 class="text-2xl font-bold mb-6">🏷️ Tạo danh mục mới</h1>

    <form action="<?php echo e(route('categories.store')); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>

        <div>
            <label class="block font-semibold">Tên danh mục</label>
            <input type="text" name="name" class="w-full border px-4 py-2 rounded" required>
        </div>

        <div>
            <label class="block font-semibold">Danh mục cha (nếu có)</label>
            <select name="parent_id" class="w-full border px-4 py-2 rounded">
                <option value="">— Không chọn —</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">💾 Lưu</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mac/xeghep247/resources/views/dashboard/danh-muc/create.blade.php ENDPATH**/ ?>