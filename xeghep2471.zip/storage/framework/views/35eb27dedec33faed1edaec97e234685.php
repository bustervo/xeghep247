<option value="<?php echo e($category->id); ?>">
    <?php echo e($prefix . $category->name); ?>

</option>

<?php if($category->children && $category->children->count()): ?>
    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('dashboard.danh-muc.dropdown-option', ['category' => $child, 'prefix' => $prefix . '— '], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /Users/mac/xeghep247/resources/views/dashboard/danh-muc/dropdown-option.blade.php ENDPATH**/ ?>