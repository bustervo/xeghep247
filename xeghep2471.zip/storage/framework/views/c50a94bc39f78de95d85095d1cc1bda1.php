<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Đăng nhập | Xe Ghép 247'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('build/assets/app.css')); ?>">
</head>
<body class="bg-gray-100 text-gray-900 font-sans">
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH /Users/mac/xeghep247/resources/views/layouts/auth.blade.php ENDPATH**/ ?>