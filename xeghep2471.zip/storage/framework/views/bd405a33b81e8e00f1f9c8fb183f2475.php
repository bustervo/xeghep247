<?php $__env->startSection('title', $post->title . ' | Xe Ghép 247'); ?>

<?php $__env->startSection('meta'); ?>
  <meta name="description" content="<?php echo e(Str::limit(strip_tags($post->excerpt ?? $post->content), 160)); ?>">
  <link rel="canonical" href="<?php echo e(url($post->slug . '.html')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<main style="max-width: 800px; margin: auto; padding: 40px 20px; font-family: 'Segoe UI', sans-serif; line-height: 1.7; color: #333;">

  <!-- Breadcrumb -->
  <nav class="breadcrumb" aria-label="breadcrumb" style="font-size: 14px; color: #777; margin-bottom: 16px;">
    <span>
      <a href="<?php echo e(url('/')); ?>" style="color: #2e7d32; text-decoration: none;">Trang chủ</a> &raquo; 
      <a href="<?php echo e(route('posts.public')); ?>" style="color: #2e7d32; text-decoration: none;">Tin tức</a> &raquo; 
      <?php echo e($post->title); ?>

    </span>
  </nav>

  <!-- Tiêu đề và ngày -->
  <h1 style="color: #1b5e20; font-size: 28px; font-weight: 700; margin-bottom: 8px;"><?php echo e($post->title); ?></h1>
  <div style="font-size: 14px; color: #888; margin-bottom: 20px;">
    📅 Ngày đăng: <?php echo e(\Carbon\Carbon::parse($post->published_at)->format('d/m/Y')); ?> | ✍️ Tác giả: Xe Ghép 247
  </div>

  <!-- Ảnh chính nếu có -->
  <?php if($post->featured_image): ?>
    <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>" alt="<?php echo e($post->title); ?>"
         style="width: 100%; border-radius: 12px; margin-bottom: 24px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
  <?php endif; ?>

  <!-- Nội dung bài viết từ CSDL -->
  <article style="margin-top: 30px; font-size: 16px;">
    <?php echo $post->content; ?>

  </article>

  <!-- Nút đặt xe -->
  <div style="text-align: center; margin-top: 32px;">
    <a href="https://zalo.me/0793459687" target="_blank"
       style="background: #2e7d32; color: #fff; padding: 14px 28px; border-radius: 8px;
              font-size: 16px; font-weight: 600; text-decoration: none; display: inline-block;
              box-shadow: 0 4px 8px rgba(0,0,0,0.1); transition: background 0.3s ease;">
      👉 Đặt xe ngay qua Zalo
    </a>
  </div>

  <!-- Tin liên quan -->
  <h2 style="color: #2e7d32; font-size: 20px; margin-top: 40px;">📰 Tin liên quan</h2>
<ul style="margin-left: 20px;">
  <?php $__empty_1 = true; $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li>
      <a href="<?php echo e(url($related->slug . '.html')); ?>" style="color: #2e7d32; text-decoration: underline;">
        📝 <?php echo e($related->title); ?>

      </a>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li>Không có bài viết liên quan</li>
  <?php endif; ?>
</ul>



</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mac/xeghep247/resources/views/chi-tiet-tin-tuc.blade.php ENDPATH**/ ?>