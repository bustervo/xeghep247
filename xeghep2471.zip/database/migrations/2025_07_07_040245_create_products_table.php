<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
      $table->id();
        $table->string('from');             // điểm đi
        $table->string('to');               // điểm đến
        $table->integer('price');           // giá (VND)
        $table->string('duration');         // thời gian di chuyển
        $table->string('zalo_link');        // link zalo riêng
        $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
